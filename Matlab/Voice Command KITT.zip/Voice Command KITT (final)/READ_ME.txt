Voice commands
1) Add all files in folder "voice command functions" in desired path
2) Add variable "LDA_model_OO_EE_Stop" to workspace
3) Run function "voiceCommand"