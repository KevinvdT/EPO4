%distance_pgon
% Usage:
% dist = distance_pgon(x,pgon)
% compute the distance between a point x and a (general) polygon object
% that could include multiple regions and holes. 
%