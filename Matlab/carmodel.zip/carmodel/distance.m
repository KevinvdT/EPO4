%distance(x,lineseg)
% compute the distance between a point x and a line segment
%Usage: 
% dist = distance(x,lineseg)
%
